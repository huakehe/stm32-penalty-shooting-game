#include "stm32l476xx.h"

#include "I2C.h"
#include "LCD.h"
#include "SysClock.h"
#include "UART.h"

#include <string.h>
#include <stdio.h>

uint32_t volatile currentValue = 0;
uint32_t volatile lastValue = 0;
uint32_t volatile overflowCount = 0;
uint32_t volatile timeInterval = 0;
uint32_t volatile send = 0;
uint32_t volatile shoot = 0;

// Button Interrupt Handler Initialization
void EXTI_Init(void) {
	// Initialize PA1,PA5

	GPIOA->MODER &= ~GPIO_MODER_MODE1_0;
	GPIOA->MODER &= ~GPIO_MODER_MODE1_1;
	
	GPIOA->MODER &= ~GPIO_MODER_MODE5_0;
	GPIOA->MODER &= ~GPIO_MODER_MODE5_1;

	// PUPDR

	GPIOA->PUPDR &= ~GPIO_PUPDR_PUPD1_0;
	GPIOA->PUPDR |= GPIO_PUPDR_PUPD1_1;
	
	GPIOA->PUPDR &= ~GPIO_PUPDR_PUPD5_0;
	GPIOA->PUPDR |= GPIO_PUPDR_PUPD5_1;

	// Configure SYSCFG EXTI

	SYSCFG->EXTICR[0] &= ~SYSCFG_EXTICR1_EXTI1; 
	SYSCFG->EXTICR[0] |= SYSCFG_EXTICR1_EXTI1_PA;
	
	SYSCFG->EXTICR[0] &= ~SYSCFG_EXTICR2_EXTI5; 
	SYSCFG->EXTICR[0] |= SYSCFG_EXTICR2_EXTI5_PA;


	// Configure EXTI Trigger

	EXTI->FTSR1 |= EXTI_FTSR1_FT1;
	EXTI->FTSR1 |= EXTI_FTSR1_FT5;

	
	// Enable EXTI
	EXTI->IMR1 |= EXTI_IMR1_IM1;
	EXTI->IMR1 |= EXTI_IMR1_IM5;
	
	// Configure and Enable in NVIC
	
	NVIC_EnableIRQ(EXTI1_IRQn); 
	NVIC_SetPriority(EXTI1_IRQn, 0);
	
	NVIC_EnableIRQ(EXTI9_5_IRQn); 
	NVIC_SetPriority(EXTI9_5_IRQn, 0);

}


// Left button interrupt handler configuration
void EXTI1_IRQHandler(void){
	EXTI->PR1 |= EXTI_PR1_PIF1;
	if(TIM1->CCR2<260)
		TIM1->CCR2 = TIM1->CCR2 + 30;
}

// Right button interrupt handler configuration
void EXTI9_5_IRQHandler(void){
	EXTI->PR1 |= EXTI_PR1_PIF5;
	if(TIM1->CCR2>70)
		TIM1->CCR2 = TIM1->CCR2 - 30;
}

// Buttons initialization
void Button_Init() {
	// Enable HSI
	RCC->CR |= RCC_CR_HSION;
	while((RCC->CR & RCC_CR_HSIRDY) == 0);
	
	// Select HSI as system clock source
	RCC->CFGR &= ~RCC_CFGR_SW;
	RCC->CFGR |= RCC_CFGR_SW_HSI;
	while((RCC->CFGR & RCC_CFGR_SWS) == 0);
	
	// Enable GPIO Clocks
	RCC->AHB2ENR |= RCC_AHB2ENR_GPIOAEN;

	// Initialize Button PA1, PA5

	GPIOA->MODER &= ~GPIO_MODER_MODE1_0;
	GPIOA->MODER &= ~GPIO_MODER_MODE1_1;
	
	GPIOA->MODER &= ~GPIO_MODER_MODE5_0;
	GPIOA->MODER &= ~GPIO_MODER_MODE5_1;
	
	// PUPDR
	
	GPIOA->PUPDR &= ~GPIO_PUPDR_PUPD1_0;
	GPIOA->PUPDR |= GPIO_PUPDR_PUPD1_1;
	
	GPIOA->PUPDR &= ~GPIO_PUPDR_PUPD5_0;
	GPIOA->PUPDR |= GPIO_PUPDR_PUPD5_1;
	
}

// PWM initialization for attacker shooting angle servo
void PWM1_Init() {
	// Enable GPIO Port E Clock
	RCC->AHB2ENR |= RCC_AHB2ENR_GPIOEEN;
	// Enable TIM1 Clock
	RCC->APB2ENR |= RCC_APB2ENR_TIM1EN;
	
	// Configure PE8
	GPIOE->MODER &= ~GPIO_MODER_MODE8_0;                   
	GPIOE->MODER |= GPIO_MODER_MODE8_1;
	GPIOE->OSPEEDR |= GPIO_OSPEEDER_OSPEEDR8;
	GPIOE->PUPDR &= ~GPIO_PUPDR_PUPD8;
	
	GPIOE->AFR[1] &= ~GPIO_AFRH_AFSEL8_3;
	GPIOE->AFR[1] &= ~GPIO_AFRH_AFSEL8_2;
	GPIOE->AFR[1] &= ~GPIO_AFRH_AFSEL8_1;
	GPIOE->AFR[1] |= GPIO_AFRH_AFSEL8_0;
	
	// Configure PWM Output for TIM1 CH 1N
	TIM1->CR1 &= ~TIM_CR1_DIR;	//COUNTING UP
	TIM1->PSC = 235;	
	TIM1->ARR = 19999; 	
	TIM1->CCMR1 |= TIM_CCMR1_OC1CE; // CLEAR THE OUTPUT COMPARE MODE BITS
	
	TIM1->CCMR1 &= ~TIM_CCMR1_OC1M_0; // PWM MODE 1
	TIM1->CCMR1 |= TIM_CCMR1_OC1M_1;
	TIM1->CCMR1 |= TIM_CCMR1_OC1M_2;
	TIM1->CCMR1 &= ~TIM_CCMR1_OC1M_3;
	
	TIM1->CCMR1 |= TIM_CCMR1_OC1PE; //PRELOAD ENABLE
	
	TIM1->CCER |= TIM_CCER_CC1P; // ACTIVE HIGH POLARITY FOR CHAN 1
	
	TIM1->CCER |= TIM_CCER_CC1NE; //OUTPUT ENABLE
	
	TIM1->BDTR |= TIM_BDTR_MOE; //MAIN OUTPUT ENABLE
	
	TIM1->CCR1 = 0;  
	
	TIM1->CR1 |= TIM_CR1_CEN; // ENABLE COUNTER
}	

// PWM initialization for defender servo
void PWM2_Init() {
	// Enable GPIO Port E Clock
	RCC->AHB2ENR |= RCC_AHB2ENR_GPIOEEN;
	// Enable TIM1 Clock
	RCC->APB2ENR |= RCC_APB2ENR_TIM1EN;
	
	// Configure PE10
	GPIOE->MODER &= ~GPIO_MODER_MODE10_0;                   
	GPIOE->MODER |= GPIO_MODER_MODE10_1;
	GPIOE->OSPEEDR |= GPIO_OSPEEDER_OSPEEDR10;
	GPIOE->PUPDR &= ~GPIO_PUPDR_PUPD10;
	
	GPIOE->AFR[1] &= ~GPIO_AFRH_AFSEL10_3;
	GPIOE->AFR[1] &= ~GPIO_AFRH_AFSEL10_2;
	GPIOE->AFR[1] &= ~GPIO_AFRH_AFSEL10_1;
	GPIOE->AFR[1] |= GPIO_AFRH_AFSEL10_0;
	
	// Configure PWM Output for TIM1 CH 2N
	// TODO
	TIM1->CR1 &= ~TIM_CR1_DIR;	//COUNTING UP
	TIM1->PSC = 160;	
	TIM1->ARR = 1999; 	
	
	TIM1->CCMR1 |= TIM_CCMR1_OC2CE; // CLEAR THE OUTPUT COMPARE MODE BITS
	TIM1->CCMR1 &= ~TIM_CCMR1_OC2M_0; // PWM MODE 1
	TIM1->CCMR1 |= TIM_CCMR1_OC2M_1;
	TIM1->CCMR1 |= TIM_CCMR1_OC2M_2;
	TIM1->CCMR1 &= ~TIM_CCMR1_OC2M_3;
	TIM1->CCMR1 |= TIM_CCMR1_OC2PE; //PRELOAD ENABLE
	TIM1->CCER |= TIM_CCER_CC2P; // ACTIVE HIGH POLARITY FOR CHAN 1
	TIM1->CCER |= TIM_CCER_CC2NE; //OUTPUT ENABLE
	TIM1->BDTR |= TIM_BDTR_MOE; //MAIN OUTPUT ENABLE
	
	TIM1->CCR2 = 160;
	
	TIM1->CR1 |= TIM_CR1_CEN; // ENABLE COUNTER
}	

//PWM initialization for ball-releasing servo
void PWM3_Init() {
	// Enable GPIO Port E Clock
	RCC->AHB2ENR |= RCC_AHB2ENR_GPIOEEN;
	// Enable TIM1 Clock
	RCC->APB2ENR |= RCC_APB2ENR_TIM1EN;
	
	// Configure PE10
	GPIOE->MODER &= ~GPIO_MODER_MODE12_0;                   
	GPIOE->MODER |= GPIO_MODER_MODE12_1;
	GPIOE->OSPEEDR |= GPIO_OSPEEDER_OSPEEDR12;
	GPIOE->PUPDR &= ~GPIO_PUPDR_PUPD12;
	
	GPIOE->AFR[1] &= ~GPIO_AFRH_AFSEL12_3;
	GPIOE->AFR[1] &= ~GPIO_AFRH_AFSEL12_2;
	GPIOE->AFR[1] &= ~GPIO_AFRH_AFSEL12_1;
	GPIOE->AFR[1] |= GPIO_AFRH_AFSEL12_0;
	
	// Configure PWM Output for TIM1 CH 2N
	TIM1->CR1 &= ~TIM_CR1_DIR;	//COUNTING UP
	TIM1->PSC = 160;	
	TIM1->ARR = 1999; 	
	
	TIM1->CCMR2 |= TIM_CCMR2_OC3CE; // CLEAR THE OUTPUT COMPARE MODE BITS
	TIM1->CCMR2 &= ~TIM_CCMR2_OC3M_0; // PWM MODE 1
	TIM1->CCMR2 |= TIM_CCMR2_OC3M_1;
	TIM1->CCMR2 |= TIM_CCMR2_OC3M_2;
	TIM1->CCMR2 &= ~TIM_CCMR2_OC3M_3;
	TIM1->CCMR2 |= TIM_CCMR2_OC3PE; //PRELOAD ENABLE
	TIM1->CCER |= TIM_CCER_CC3P; // ACTIVE HIGH POLARITY FOR CHAN 1
	TIM1->CCER |= TIM_CCER_CC3NE; // OUTPUT ENABLE
	TIM1->BDTR |= TIM_BDTR_MOE; //MAIN OUTPUT ENABLE
	
	TIM1->CCR3 = 170;  
	
	TIM1->CR1 |= TIM_CR1_CEN; // ENABLE COUNTER
}	


// Setup the input capture for ultrasonic sensor
void Input_Capture_Setup() {
	
	RCC->AHB2ENR |= RCC_AHB2ENR_GPIOBEN;
	//MODER TO ALTERNATIVE FUNCTION
	GPIOB->MODER |= GPIO_MODER_MODE3_1;
	GPIOB->MODER &= ~GPIO_MODER_MODE3_0;
	//CHANNEL TIM4_CH1 TO TIM2-CH2
	GPIOB->AFR[0] &= ~GPIO_AFRL_AFSEL3_3;
	GPIOB->AFR[0] &= ~GPIO_AFRL_AFSEL3_2;
	GPIOB->AFR[0] &= ~GPIO_AFRL_AFSEL3_1;
	GPIOB->AFR[0] |= GPIO_AFRL_AFSEL3_0;
	//NO PULL UP OR NO PULL DOWN
	GPIOB->PUPDR &= ~GPIO_PUPDR_PUPD3;
	
	//ENABLE TIMER 4 IN RCC_APB1ENRB
	RCC->APB1ENR1 |= RCC_APB1ENR1_TIM2EN;

	//ENABLE  auto reload preload in the control register 
	TIM2->CR1 |= TIM_CR1_ARPE;
	
	//SET ARR TO MAX
	TIM2->ARR = 0xFFFF;
	
	//set prescaler
	TIM2->PSC = 79;
	
	//IN THE CCMR, SET INPUT CAPUTRE TO TIMER INPUT 1, 01
	TIM2->CCMR1 &= ~TIM_CCMR1_CC2S_1;
	TIM2->CCMR1 |= TIM_CCMR1_CC2S_0;	
	
	//BOTH RISING AND FALLING EDGE FOR INPUT 11
	TIM2->CCER |= TIM_CCER_CC2P;
	TIM2->CCER |= TIM_CCER_CC2NP;
	
	//ENABLE CAPTURING
	TIM2->CCER |= TIM_CCER_CC2E;
	
	//DMA REGISTER
	//IN THE DMA/INTERRUPT ENABLE REGISTER
	TIM2->DIER |= TIM_DIER_CC2DE;
	//capture/compare 1 interrupt enable
	TIM2->DIER |= TIM_DIER_CC2IE;
	//update interrupt enable
	TIM2->DIER |= TIM_DIER_UIE;
	
	//ENABLE UPDATE GENERATION IN EGR
	TIM2->EGR |= TIM_EGR_UG;
	
	//CLEAR UPDATE INTERRUPT FLAG
	TIM2->SR &= ~TIM_SR_UIF;
	
	//SET THE DIRECTION OF THE COUNTER, COUNT UP?
	TIM2->CR1 &= ~TIM_CR1_DIR;
	
	// ENABLE COUNTER
	TIM2->CR1 |= TIM_CR1_CEN; 
	
	//Enable the interrupt in the NVIC 
	//and set it to have the highest priority.
	NVIC_EnableIRQ(TIM2_IRQn); 
	NVIC_SetPriority(TIM2_IRQn, 2);
	
}

// TIM2 interrupt handler for ultrasonic sensor
void TIM2_IRQHandler(void) {
	
	if((TIM2->SR & TIM_SR_CC2IF) != 0){ // if counter value is captured in CCR1
		// update current counter value
		currentValue = TIM2->CCR2;
		if((GPIOB->IDR & GPIO_IDR_ID3) ){ // rising edge detected
			// update last counter value
			lastValue = TIM2->CCR2;
			// reset overflow count when a new rising edge is detected
			overflowCount = 0;
			// reset to not input capture occured
			TIM2->SR &= ~TIM_SR_CC2IF;
		}
		if((GPIOB->IDR & GPIO_IDR_ID3) == 0){
			timeInterval = (currentValue + overflowCount*(0xFFFF+1) - lastValue);
			// reset to not input capture occured
			TIM2->SR &= ~TIM_SR_CC2IF;
		}
	}
	if((TIM2->SR & TIM_SR_UIF) != 0){ // if an overflow happens
		overflowCount++;
		TIM2->SR &= ~TIM_SR_UIF;
	}
	

	
	
}

// Setup for ultrasonic sensor trigger
void Trigger_Setup() {
	
	//TIM5 CH1
	//ENABLE GPIO PE11
	RCC->AHB2ENR |= RCC_AHB2ENR_GPIOAEN; 
	//MODER TO ALTERNATIVE FUNCTION
	GPIOA->MODER |= GPIO_MODER_MODE0_1;
	GPIOA->MODER &= ~GPIO_MODER_MODE0_0;
	
	GPIOA->AFR[0] &= ~GPIO_AFRL_AFSEL0_3;
	GPIOA->AFR[0] &= ~GPIO_AFRL_AFSEL0_2;
	GPIOA->AFR[0] |= GPIO_AFRL_AFSEL0_1;
	GPIOA->AFR[0] &= ~GPIO_AFRL_AFSEL0_0;
	//NO PULL UP OR NO PULL DOWN
	GPIOA->PUPDR &= ~GPIO_PUPDR_PUPD0;
	//Set output type to push pull,
	GPIOA->OTYPER &= ~GPIO_OTYPER_OT0;
	
	//SET OUTPUT SPEED TO VERY HIGH
	GPIOA->OSPEEDR |= GPIO_OSPEEDER_OSPEEDR0;
	
	//Enable timer 5 
	RCC->APB1ENR1 |= RCC_APB1ENR1_TIM5EN;
	
	//set prescaler 
	TIM5->PSC = 79;
	
	//enable auto reload preload in the control register
	TIM5->CR1 |= TIM_CR1_ARPE;
	
	//set arr to max
	TIM5->ARR = 0xFFFF;
	
	//set the CCR
	TIM5->CCR1 = 10;
	
	//Set the output control mode such that timer is in PWM Mode 1
	TIM5->CCMR1 &= ~TIM_CCMR1_OC1M_0; // PWM MODE 1
	TIM5->CCMR1 |= TIM_CCMR1_OC1M_1;
	TIM5->CCMR1 |= TIM_CCMR1_OC1M_2;
	TIM5->CCMR1 &= ~TIM_CCMR1_OC1M_3;
	
	// Enable the output compare mode
	TIM5->CCMR1 |= TIM_CCMR1_OC1PE;
	
	// Enable the output in the capture/compare enable register
	TIM5->CCER |= TIM_CCER_CC1E;
	
	//break and dead-time register, off-state selection for run mode to enable
	TIM5->BDTR |= TIM_BDTR_OSSR |TIM_BDTR_MOE;
	
	//enable update generation in EGR
	TIM5->EGR |= TIM_EGR_UG;
	
	//ENABLE UPDATE INTERRUPT
	TIM5->DIER |= TIM_DIER_UIE;
	
	//CLEAR UPDATE INTERRUPT FLAG
	TIM5->SR &= ~TIM_SR_UIF; 
	
	//SET THE DIRECTION OF THE COUNTER, COUNT DOWN
	TIM5->CR1 |= TIM_CR1_DIR;
	
	//Enable the counter
	TIM5->CR1 |= TIM_CR1_CEN;
}



//USART initialization for bluetooth module
void Init_USARTx(int part) {
	if(part == 1) {
		UART2_Init();
		UART2_GPIO_Init();
		USART_Init(USART2);
	} else if(part == 2) {
		UART1_Init();
		UART1_GPIO_Init();
		USART_Init(USART1);
	} else {
		// Do nothing...
	}
}
int main(void) {
	System_Clock_Init(); // System Clock = 80 MHz
	Init_USARTx(1);
	
	Button_Init();
	
	EXTI_Init();
	
	PWM1_Init(); // nunchuck
	PWM2_Init(); // BUTTON
	PWM3_Init(); // Z BUTTON

	// for ultrasonic sensor
	Input_Capture_Setup();
	Trigger_Setup();
	TIM2_IRQHandler();
	
	
	LCD_Initialization();
	LCD_Clear();
	
	// Initialize I2C
	I2C_GPIO_Init();
	I2C_Initialization();

	char message[6];
	uint8_t SlaveAddress;
	uint8_t Data_Receive[6];
	uint8_t Data_Send[6];
	
	
	while(1) {	
		// print ultrasonic sensor distance
		sprintf(message,"%6d", (timeInterval/5));
		LCD_DisplayString(message);
		
		SlaveAddress = 0b10100100; // Slave address for wii
		
		//write 0x40 and 0x00 to slave address 0xA4 to init
		Data_Send[0] = 0x40;
		I2C_SendData(I2C1, SlaveAddress, Data_Send, 1);
		Data_Send[0] = 0x0;
		I2C_SendData(I2C1, SlaveAddress, Data_Send, 1);
		

		I2C_ReceiveData(I2C1, SlaveAddress, Data_Receive, 6);
		int temp;
		int z;
		int c;
		
		// [0] is x, [1] is y, [5] lsb is z-button, [5] second to last bit is c-button, c is not used though
		temp = Data_Receive[0];
		z = Data_Receive[5]&0x1;
		c = Data_Receive[5]&0x2;
		TIM1->CCR1 = -0.15*(uint32_t)(temp)+165;
		
		if(z==0){
			TIM1->CCR3 = 160;
			send = 0;
			shoot = 1;
			
		}
		else{
			TIM1->CCR3 = 230;
		}
		
		if(shoot == 1){
			for(int i=0;i<3000000;i++);
			if(timeInterval/5<30 && timeInterval/5!=0  && send == 0){
					// send to android app, f is attacker score
					printf("f");
					send = -1;
					shoot = 0;
			}else{
				// send to android app, u is defender score
				printf("u");
				send = -1;
				shoot = 0;
			}
		}
		
		int i;
		for(i = 0; i < 500000; ++i); 
	}
}
