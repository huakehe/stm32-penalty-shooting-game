package com.example.danyal.bluetoothhc05;

import android.app.ProgressDialog;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothSocket;
import android.content.Intent;
import android.os.AsyncTask;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.UUID;

public class ScoreReceive extends AppCompatActivity {

    Button btn1, btn2, btn3, btn4, btn5, btnDis;
    String address = null;
    TextView  display;
    private ProgressDialog progress;
    BluetoothAdapter myBluetooth = null;
    BluetoothSocket btSocket = null;
    private boolean isBtConnected = false;
    static final UUID myUUID = UUID.fromString("00001101-0000-1000-8000-00805F9B34FB");
    ArrayList <Character> chars = new ArrayList<Character>();
    int attacker = 0;
    int defender = 0;

    InputStream ipStream;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        Intent newint = getIntent();
        address = newint.getStringExtra(DeviceList.EXTRA_ADDRESS);

        setContentView(R.layout.activity_score_receive);

        btn1 = (Button) findViewById(R.id.button2);
        btnDis = (Button) findViewById(R.id.button4);
        btn2 = (Button) findViewById(R.id.button3);
        display = (TextView)findViewById(R.id.receivedata);

        new ConnectBT().execute();

        btn1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick (View v) {
                receiveSignal("1");

            }
        });



        btn2.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick (View v) {
                attacker = 0;
                defender = 0;
                display.setText("0 : 0");
                try {
                    ipStream.reset();
                } catch (IOException e) {
                    e.printStackTrace();
                }
                sendSignal("c");


            }
        });

        btnDis.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick (View v) {
                Disconnect();
            }
        });


    }

    private void sendSignal ( String number ) {
        if ( btSocket != null ) {
            try {
                btSocket.getOutputStream().write(number.toString().getBytes());
            } catch (IOException e) {
                msg("Error");
            }
        }
    }

    private void receiveSignal(String val){
        byte [] buffer = new byte[1024];
        int bytes = 0;

        receiveThread rt = new receiveThread(bytes,buffer);
        rt.start();
    }

    private void Disconnect () {
        if ( btSocket!=null ) {
            try {
                btSocket.close();
            } catch(IOException e) {
                msg("Error");
            }
        }

        finish();
    }

    private void msg (String s) {
        Toast.makeText(getApplicationContext(), s, Toast.LENGTH_LONG).show();
    }

    private class ConnectBT extends AsyncTask<Void, Void, Void> {
        private boolean ConnectSuccess = true;

        @Override
        protected  void onPreExecute () {
            progress = ProgressDialog.show(ScoreReceive.this, "Connecting...", "Please Wait!!!");
        }

        @Override
        protected Void doInBackground (Void... devices) {
            try {
                if ( btSocket==null || !isBtConnected ) {
                    myBluetooth = BluetoothAdapter.getDefaultAdapter();
                    BluetoothDevice dispositivo = myBluetooth.getRemoteDevice(address);
                    btSocket = dispositivo.createInsecureRfcommSocketToServiceRecord(myUUID);
                    BluetoothAdapter.getDefaultAdapter().cancelDiscovery();
                    btSocket.connect();
                }
            } catch (IOException e) {
                ConnectSuccess = false;
            }

            return null;
        }

        @Override
        protected void onPostExecute (Void result) {
            super.onPostExecute(result);

            if (!ConnectSuccess) {
                msg("Connection Failed. Is it a SPP Bluetooth? Try again.");
                finish();
            } else {
                msg("Connected");
                isBtConnected = true;
            }

            progress.dismiss();
        }
    }

    private class receiveThread extends Thread{
        byte [] buffer = new byte[6];
        int bytes;


        receiveThread(int bytes, byte [] buffer) {
            this.bytes = bytes;
            this.buffer = buffer;
        }
        public void run() {
            Log.d("msg","receive successful");
            int i=0;
            while (true) {
                //Log.d("msg","receive successful");

                try {

                    ipStream = btSocket.getInputStream();
                    int a = ipStream.read();
                    chars.add((char)a);
                    String str = null;
                    Log.d("msg","bytes are "+ chars.get(chars.size()-1));
                    i++;
                    //display.setText(chars.get(0));
                    //Log.v("msg","receive successful");

                    //everytime receive print the score
                    attacker = 0;
                    defender = 0;
                    int temp = -1;

                    if(chars.size()!=0&&chars.size()!=temp){
                        for(int x=0;x<chars.size();x++){
                            if(chars.get(x)=='f'){
                                attacker++;
                                temp=chars.size();
                            }
                            else if(chars.get(x)=='u'){
                                defender++;
                                temp=chars.size();
                            }
                        }
                    }
                    display.setText(Integer.toString(attacker)+ " : "+Integer.toString(defender));

                } catch (IOException e) {
                    e.printStackTrace();
                    //Log.v("fail msg","damn it fails");
                }
            }
        }
    }
}
